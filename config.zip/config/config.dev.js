window.config = {
    name: 'John Doe',
    title: 'Full Stack Developer',
    bio: 'Passionate about creating scalable web applications and solving complex problems',
    location: 'San Francisco',
    email: 'john.doe@example.com',
    image: 'https://via.placeholder.com/150'
};